// ========== Stripe決済リンク設定 ==========
// 以下のリンクを実際のStripe決済リンクに置き換えてください
const APPLICATION_LINKS = {
    'no-tax': 'https://buy.stripe.com/実際の消費税申告なしプランのリンク', // 消費税申告なしプラン
    'with-tax': 'https://buy.stripe.com/実際の消費税申告ありプランのリンク' // 消費税申告ありプラン
};

// ========== プラン申し込み処理 ==========
function applyPlan(planType) {
    const termsCheckbox = document.getElementById('terms-agreement');
    const errorElement = document.getElementById(`error-${planType}`);
    
    if (!termsCheckbox.checked) {
        // エラーメッセージを表示
        errorElement.style.display = 'block';
        return;
    }
    
    // エラーメッセージを非表示
    errorElement.style.display = 'none';
    
    // お申し込み処理（Stripe決済ページに遷移）
    if (APPLICATION_LINKS[planType]) {
        // 新しいタブでお申し込み・決済ページを開く
        window.open(APPLICATION_LINKS[planType], '_blank');
        
        // お申し込みページ移動の追跡
        trackApplicationClick(planType);
        
        // 確認メッセージ（オプション）
        // alert('お申し込みページを開きました。新しいタブで手続きを完了してください。');
    } else {
        alert('申し訳ありません。お申し込みページの設定に問題があります。お問い合わせください。');
    }
}

// ========== 利用規約チェックボックス機能 ==========
function initializeTermsAgreement() {
    const termsCheckbox = document.getElementById('terms-agreement');
    const planButtons = document.querySelectorAll('.plan-btn');
    
    if (termsCheckbox) {
        termsCheckbox.addEventListener('change', function() {
            planButtons.forEach(button => {
                button.disabled = !this.checked;
                
                // チェック状態に応じてボタンの見た目を変更
                if (this.checked) {
                    button.style.background = '';
                    button.style.cursor = '';
                } else {
                    button.style.background = '#d1d5db';
                    button.style.cursor = 'not-allowed';
                }
            });
            
            // エラーメッセージを非表示
            document.querySelectorAll('.error-message').forEach(error => {
                error.style.display = 'none';
            });
        });
    }
}

// ========== モバイルメニュー機能 ==========
function toggleMobileMenu() {
    // 今後の拡張用（現在はシンプルなレスポンシブデザインのみ）
    console.log('モバイルメニューがクリックされました');
}

// ========== スムーススクロール ==========
function initializeSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ========== ヘッダーのスクロール効果 ==========
function initializeHeaderEffect() {
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = 'none';
        }
    });
}

// ========== アニメーション効果 ==========
function initializeAnimations() {
    // Intersection Observer を使用してスクロール時のアニメーションを実装
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // アニメーション対象の要素を選択
    const animateElements = document.querySelectorAll(
        '.service-card, .pricing-card, .faq-item'
    );
    
    animateElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}

// ========== フォームバリデーション（将来の拡張用） ==========
function validateForm(formData) {
    const errors = [];
    
    // 必要に応じてバリデーションロジックを追加
    if (!formData.email || !formData.email.includes('@')) {
        errors.push('有効なメールアドレスを入力してください。');
    }
    
    return errors;
}

// ========== Google Analytics / タグマネージャー（将来の拡張用） ==========
function trackEvent(eventName, planType = null) {
    // Google Analytics や他の分析ツールでのイベント追跡
    if (typeof gtag !== 'undefined') {
        gtag('event', eventName, {
            plan_type: planType,
            page_title: document.title,
            page_location: window.location.href
        });
    }
    
    console.log(`Event tracked: ${eventName}`, { planType });
}

// ========== 申し込みのクリック追跡 ==========
function trackApplicationClick(planType) {
    trackEvent('application_clicked', planType);
}

// ========== ページロード時の初期化 ==========
document.addEventListener('DOMContentLoaded', () => {
    console.log('みんなの税務顧問サイトが読み込まれました');
    
    // 各機能を初期化
    initializeTermsAgreement();
    initializeSmoothScroll();
    initializeHeaderEffect();
    initializeAnimations();
    
    // ページビューの追跡
    trackEvent('page_view');
});

// ========== ページ離脱時の処理 ==========
window.addEventListener('beforeunload', () => {
    // 必要に応じて離脱時の処理を追加
    console.log('ページを離脱します');
});

// ========== エラーハンドリング ==========
window.addEventListener('error', (error) => {
    console.error('JavaScriptエラーが発生しました:', error);
    
    // 本番環境では、エラーログサービスに送信することを推奨
    // 例: Sentry, LogRocket など
});

// ========== デバッグ用（開発環境でのみ有効） ==========
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('デバッグモードが有効です');
    
    // 申し込みリンクの確認
    console.log('設定されている申し込みリンク:', APPLICATION_LINKS);
    
    // 開発環境用のテスト関数
    window.testApplicationLink = function(planType) {
        console.log(`テスト: ${planType}プランの申し込みリンクをテストします`);
        if (APPLICATION_LINKS[planType]) {
            console.log(`リンク: ${APPLICATION_LINKS[planType]}`);
        } else {
            console.error(`${planType}プランの申し込みリンクが設定されていません`);
        }
    };
    
    // 利用規約チェックボックスのテスト
    window.testTermsAgreement = function() {
        const termsCheckbox = document.getElementById('terms-agreement');
        if (termsCheckbox) {
            termsCheckbox.checked = !termsCheckbox.checked;
            termsCheckbox.dispatchEvent(new Event('change'));
            console.log('利用規約チェックボックスの状態:', termsCheckbox.checked);
        }
    };
} 